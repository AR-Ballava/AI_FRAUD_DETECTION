---
title: Ai Fraud Detection
emoji: 🏃
colorFrom: green
colorTo: indigo
sdk: docker
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
