from fastapi import FastAPI
import joblib
import numpy as np

app = FastAPI()

# Load your model into memory when the server boots up
# Make sure "model.pkl" matches the exact name of your model file
model = joblib.load("model.pkl")

@app.get("/")
def home():
    return {"status": "Fraud Detection Model API is Online"}

@app.post("/predict")
def predict_fraud(data: dict):
    try:
        # Extract the features sent from your backend
        # Example input data structure: {"features": [1.0, 23.4, 0.0, 1.2]}
        features = data.get("features")
        
        # Convert to numpy array and reshape for prediction (1 sample)
        input_data = np.array(features).reshape(1, -1)
        
        # Make the prediction (0 for safe, 1 for fraud)
        prediction = model.predict(input_data)[0]
        
        # Get probability if your model supports it
        try:
            probability = model.predict_proba(input_data)[0][1]
        except AttributeError:
            probability = None

        return {
            "success": True,
            "is_fraud": int(prediction),
            "fraud_probability": float(probability) if probability is not None else "N/A"
        }
    except Exception as e:
        return {"success": False, "error": str(e)}
